<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class dashController extends Controller
{
  public function Dash(Request $request){
    $UserId = "userid";
    $pass= 123456789;

    $context = ["userid" => $UserId, "pass" => $pass];

    return view ('dashBoard', $context);
    }
}
