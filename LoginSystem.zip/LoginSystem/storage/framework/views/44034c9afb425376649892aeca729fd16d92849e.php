<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
    <h1>DASHBOARD</h1>
    <center>
        <form action= "DashBoard" method = "get">
              <h2>PaoChing</h2>
              <h3>Remaining Balance: ₱: 100,000,000.00</h3>
              <h4>Date last Widrawal: 03-28-3020</h4>
       </form>
    <center/>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\LoginSystem\resources\views/auth/dashboard.blade.php ENDPATH**/ ?>